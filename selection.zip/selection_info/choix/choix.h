#ifndef CHOIX_H_INCLUDED
#define CHOIX_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../candidat/candidat.h"
typedef struct{

    char ncin[100];
    char choix1[100];
    char choix2[100];
    char choix3[100];


} Choix;

void affiche_choix(Choix ch){

    printf("\n\n==============================================>");
    printf("\n Numero de CNI :  %s", ch.ncin);
    printf("\n Premier choix : %s", ch.choix1);
    printf("\n Deuxieme choix  :  %s", ch.choix2);
    printf("\n Troisieme choix :  %s", ch.choix3);
}

int compter_ligne_choix()
{
    FILE *f=NULL;
    int c;
    Choix ch;
    int i=0;
    int nbligne = 0;
    f = fopen("choix/choix.txt", "r");
    while(fscanf(f, "%s  %s  %s  %s\n", &ch.ncin, &ch.choix1, &ch.choix2, &ch.choix3) !=EOF)
    {
        i=i+1;
    }
    return i;
}


Choix extraction_choix(char num[100])
{

    int nb=compter_ligne_choix();
    int i=0;
    Choix ch;
    Choix tch[nb];


        FILE *f=NULL;

        f = fopen("choix/choix.txt", "r");

    if(f!=NULL)
    {
        while(fscanf(f, "%s  %s  %s  %s\n", &ch.ncin, &ch.choix1, &ch.choix2, &ch.choix3) !=EOF)
        {
            tch[i]=ch;
            i++;
        }

        for(i=0;i<nb;i++)
        {
            if(strcmp(tch[i].ncin, num)==0)
            {
                ch=tch[i];;
            }
        }

    }

    else{
        printf("\n ERREUR D'OUVERTURE DU FICHIER ! \n");
        exit(1);
    }

    return ch;


    fclose(f);
}




void enregistrer_choix(Choix ch)
{
    FILE *f;
    f = fopen("choix/choix.txt", "a");

    if(f!=NULL)
    {
        if(fprintf(f, "%s  %s  %s  %s\n", ch.ncin, ch.choix1, ch.choix2, ch.choix3))
        {

            printf("\n\nLes choix ont ete enregistres avec succes");
        }

    }
    else
    {
        printf("Erreur d'ouverture du fichier ! ");
        exit(1);

    }




    fclose(f);
}


void modifier_choix(char anum[100], Choix d)
{

    int nb=compter_ligne_choix();
    int i=0;
    Choix tch[nb];
    Choix ch;


        FILE *f=NULL;

        f = fopen("choix/choix.txt", "r");

    if(f!=NULL)
    {
        while(fscanf(f, "%s  %s  %s  %s\n", &ch.ncin, &ch.choix1, &ch.choix2, &ch.choix3) !=EOF)
        {
            tch[i]=ch;
            i=i+1;
        }


        for(i=0;i<nb;i++)
        {
            if(strcmp(tch[i].ncin, anum)==0)
            {
                tch[i]=d;
            }
        }


    }

    else{
        printf("\n ERREUR D'OUVERTURE DU FICHIER ! \n");
        exit(1);
    }



    fclose(f);


     FILE *t=NULL;
      t = fopen("choix/choix.txt", "w+");

       if(f!=NULL)
        {
            for(i=0;i<nb;i++)
            {
                if(fprintf(t, "%s  %s  %s  %s\n", tch[i].ncin, tch[i].choix1, tch[i].choix2, tch[i].choix3))
                {

                }
            }


        }
        else
        {
            printf("Erreur d'ouverture du fichier ! ");
            exit(1);

        }

    fclose(t);

}



void supprimer_choix(char num[100])
{
    int nb=compter_ligne_choix();
    int i=0;
    int j=0;
    Choix tch[nb];
    Choix ch;


        FILE *f=NULL;

        f = fopen("choix/choix.txt", "r");

    if(f!=NULL)
    {
        while(fscanf(f, "%s  %s  %s  %s\n", &ch.ncin, &ch.choix1, &ch.choix2, &ch.choix3) !=EOF)
        {
            tch[i]=ch;
            i=i+1;
        }


        for(i=0;i<nb;i++)
        {
            if(strcmp(tch[i].ncin, num)==0)
            {
                j=i;
            }
        }

        for(i=j;i<nb-1;i++)
        {
            tch[i] = tch[i+1];
        }


    }

    else{
        printf("\n ERREUR D'OUVERTURE DU FICHIER ! \n");
        exit(1);
    }



    fclose(f);

     FILE *t=NULL;
      t = fopen("choix/choix.txt", "w+");

       if(t!=NULL)
        {
            for(i=0;i<nb-1;i++)
            {
                if(fprintf(t, "%s  %s  %s  %s\n", tch[i].ncin, tch[i].choix1, tch[i].choix2, tch[i].choix3))
                {

                }
            }


        }
        else
        {
            printf("Erreur d'ouverture du fichier ! ");
            exit(1);

        }

    fclose(t);



}
#endif // CHOIX_H_INCLUDED
