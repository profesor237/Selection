#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "candidat/candidat.h"
#include "bacc/bacc.h"
#include "choix/choix.h"

void modifier()
{
    char anum[100];
    int v;
    printf("\n\n=================== MODIFICATION DES INFORMATIONS ========================\n\n");
    printf("\n Entrer le numero du candidat dont vous souhaitez modifier les informations : ");
    scanf("%s", &anum);
    v = verifier(anum);
    if(v==0)
    {
        printf("************************************************\n");
        printf("*                                              *\n");
        printf("*     CE NUMERO N\'A JAMAIS ETE ENREGISTRE      *\n");
        printf("*                                              *\n");
        printf("************************************************\n");
    }
    else
    {
        Candidat c;
        Bacc b;
        Choix ch;
        int a, moy, math, phy, nb;
        char no[100], pre[100], num[100], serie[100], ch1[100], ch2[100], ch3[100];

        printf(" ============  Entrez les nouvelles informations du candidat  ================== \n\n");

        printf("Quel est votre nom : ");
        scanf("%s", &no);
        printf("Quel est votre prenom : ");
        scanf("%s", &pre);
        printf("Quel est votre age : ");
        scanf("%d", &a);
        printf("Quel est votre numero : ");
        scanf("%s", &num);
        printf("Queelle serie avez-vous fait? : ");
        scanf("%s", &serie);
        printf("Queelle est votre moyenne au Bacc? : ");
        scanf("%d", &moy);
        printf("Quelle est la note obtenue en Math? : ");
        scanf("%d", &math);
        printf("Quelle est la note obtenue en Physique? : ");
        scanf("%d", &phy);
        printf("Quel est votre premier choix de fili�re? : ");
        scanf("%s", &ch1);
        printf("Quel est votre deuxieme choix de fili�re? : ");
        scanf("%s", &ch2);
        printf("Quel est votre troisieme choix de fili�re? : ");
        scanf("%s", &ch3);

        strcpy(c.nom, no);
        strcpy(c.prenom, pre);
        strcpy(c.ncin, num);
        c.age = a;
        modifier_candidat(anum, c);

        strcpy(b.ncin, num);
        strcpy(b.seriebacc, serie);
        b.moyenne = moy;
        b.notemath = math;
        b.notephy = phy;
        modifier_bacc(anum, b);

        strcpy(ch.ncin, num);
        strcpy(ch.choix1, ch1);
        strcpy(ch.choix2, ch2);
        strcpy(ch.choix3, ch3);
        modifier_choix(anum, ch);

        printf("\n\\n");
        printf("************************************************\n");
        printf("*                                              *\n");
        printf("*    Les nouvelles informations du candidat    *\n");
        printf("*            bien ete enregistres              *\n");
        printf("************************************************\n");

    }
}







int main()
{
    Candidat c;
    Bacc b;
    Choix ch;
    int a=18;
    int i;
    int moy=19; int math=17;  int phy=14; int nb;
    char no[100]="Ngenkam"; char pre[100]="Donald"; char num[100]="CE346"; char serie[100]="TI"; char ch1[100]="INFO";
    char ch2[100]="GEOGRAPHIE"; char ch3[100]="lettre";
    char anum[100]="CE644";
    nb=compter_ligne_candidat();
    printf("%d", nb);
    //supprimer_candidat(anum);
    //supprimer_bacc(anum);
    selection();
    //ch=extraction_choix(anum);
    //affiche_choix(ch);



    /*strcpy(ch.ncin, num);
    strcpy(ch.choix1, ch1);
    strcpy(ch.choix2, ch2);
    strcpy(ch.choix3, ch3);
    modifier_choix(anum, ch);

    strcpy(c.nom, no);
    strcpy(c.prenom, pre);
    strcpy(c.ncin, num);
    c.age = a;
    modifier_candidat(anum, c);

    strcpy(b.ncin, num);
    strcpy(b.seriebacc, serie);
    b.moyenne = moy;
    b.notemath = math;
    b.notephy = phy;
    modifier_bacc(anum, b);







   /*printf("Quel est votre nom : ");
    scanf("%s", &no);
    printf("Quel est votre prenom : ");
    scanf("%s", &pre);
    printf("Quel est votre age : ");
    scanf("%d", &a);
    printf("Quel est votre numero : ");
    scanf("%s", &num);
    printf("Queelle serie avez-vous fait? : ");
    scanf("%s", &serie);
    printf("Queelle est votre moyenne au Bacc? : ");
    scanf("%d", &moy);
    printf("Quelle est la note obtenue en Math? : ");
    scanf("%d", &math);
    printf("Quelle est la note obtenue en Physique? : ");
    scanf("%d", &phy);
    printf("Quel est votre premier choix de fili�re? : ");
    scanf("%s", &ch1);
    printf("Quel est votre deuxieme choix de fili�re? : ");
    scanf("%s", &ch2);
    printf("Quel est votre troisieme choix de fili�re? : ");
    scanf("%s", &ch3);





    strcpy(c.nom, no);
    strcpy(c.prenom, pre);
    strcpy(c.ncin, num);
    c.age = a;
    affiche_candidat(c);
    enregistrer_candidat(c);

    strcpy(b.ncin, num);
    strcpy(b.seriebacc, serie);
    b.moyenne = moy;
    b.notemath = math;
    b.notephy = phy;
    affiche_bacc(b);
    enregistrer_bacc(b);

    strcpy(ch.ncin, num);
    strcpy(ch.choix1, ch1);
    strcpy(ch.choix2, ch2);
    strcpy(ch.choix3, ch3);
    affiche_choix(ch);
    enregistrer_choix(ch);*/




    return 0;
}
