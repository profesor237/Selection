#ifndef BACC_H_INCLUDED
#define BACC_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include "../candidat/candidat.h"
#include "../choix/choix.h"


typedef struct{

    char ncin[100];
    int moyenne;
    char seriebacc[100];
    int notemath;
    int notephy;

} Bacc;

void affiche_bacc(Bacc b){

    printf("\n\n==============================================>");
    printf("\n Numero de CNI    :  %s", b.ncin);
    printf("\n Serie : %s", b.seriebacc);
    printf("\n Moyenne :  %d", b.moyenne);
    printf("\n Note de Mathematique CNI :  %d", b.notemath);
    printf("\n Note de physique :  %d", b.notephy);

}





int compter_ligne_bacc()
{
            FILE *f=NULL;
    int i=0;
    Bacc b;
    f = fopen("bacc/bacc.txt", "r");
    while(fscanf(f,  "%s  %s  %d  %d  %d\n", &b.ncin, &b.seriebacc, &b.moyenne, &b.notemath, &b.notephy ) !=EOF)
    {
        i=i+1;
    }
    return i;
}



void enregistrer_bacc(Bacc b){

    FILE *f;
    f = fopen("bacc/bacc.txt", "a");

    if(f!=NULL){

        if(fprintf(f, "%s  %s  %d  %d  %d\n", b.ncin, b.seriebacc, b.moyenne, b.notemath, b.notephy  ))
        {
            printf("\n\nLes information du bacc ont ete enregistres avec succes");
        }

    }
    else
    {
        printf("Erreur d'ouverture du fichier ! ");
        exit(1);

    }




    fclose(f);




}



Bacc extraction_bacc(char num[100])
{

     int nb=compter_ligne_bacc();
    Bacc tb[nb];
    Bacc b;
    int i=0;


        FILE *f=NULL;

        f = fopen("bacc/bacc.txt", "r");

    if(f!=NULL)
    {
        while(fscanf(f, "%s  %s  %d  %d  %d\n", &b.ncin, &b.seriebacc, &b.moyenne, &b.notemath, &b.notephy ) !=EOF)
        {
            tb[i]=b;
            i++;

        }

                for(i=0;i<nb;i++)
        {
            if(strcmp(tb[i].ncin, num)==0)
            {
                b=tb[i];
            }
        }


    }

    else{
        printf("\n ERREUR D'OUVERTURE DU FICHIER ! \n");
        exit(1);
    }

    return b;

    fclose(f);
}



void modifier_bacc(char anum[100], Bacc d)
{

    int nb=compter_ligne_bacc();
    int i=0;
    Bacc tb[nb];
    Bacc b;


        FILE *f=NULL;

        f = fopen("bacc/bacc.txt", "r");

    if(f!=NULL)
    {
        while(fscanf(f,  "%s  %s  %d  %d  %d\n", &b.ncin, &b.seriebacc, &b.moyenne, &b.notemath, &b.notephy ) !=EOF)
        {
            tb[i]=b;
            i=i+1;
        }


        for(i=0;i<nb;i++)
        {
            if(strcmp(tb[i].ncin, anum)==0)
            {
                tb[i]=d;
            }
        }


    }

    else{
        printf("\n ERREUR D'OUVERTURE DU FICHIER ! \n");
        exit(1);
    }



    fclose(f);


     FILE *t=NULL;
      t = fopen("bacc/bacc.txt", "w+");

       if(f!=NULL)
        {
            for(i=0;i<nb;i++)
            {
                if(fprintf(t,  "%s  %s  %d  %d  %d\n", tb[i].ncin, tb[i].seriebacc, tb[i].moyenne, tb[i].notemath, tb[i].notephy ))
                {

                }
            }


        }
        else
        {
            printf("Erreur d'ouverture du fichier ! ");
            exit(1);

        }

    fclose(t);

}


void supprimer_bacc(char num[100])
{
    int nb=compter_ligne_bacc();
    int i=0;
    int j=0;
    Bacc tb[nb];
    Bacc b;


        FILE *f=NULL;

        f = fopen("bacc/bacc.txt", "r");

    if(f!=NULL)
    {
        while(fscanf(f, "%s  %s  %d  %d  %d\n", &b.ncin, &b.seriebacc, &b.moyenne, &b.notemath, &b.notephy ) !=EOF)
        {
            tb[i]=b;
            i=i+1;
        }


        for(i=0;i<nb;i++)
        {
            if(strcmp(tb[i].ncin, num)==0)
            {
                j=i;
            }
        }
        for(i=0;i<nb;i++)
        {
            affiche_bacc(tb[i]);
        }

        if(j!=0)
        {
            printf("L'element se trouve dans le fichier");
            for(i=j;i<nb-1;i++)
            {
                tb[i] = tb[i+1];
            }
            for(i=0;i<nb;i++)
            {
                affiche_bacc(tb[i]);
            }
        }



    }

    else{
        printf("\n ERREUR D'OUVERTURE DU FICHIER ! \n");
        exit(1);
    }



    fclose(f);

    if(j!=0)
    {
        FILE *t=NULL;
      t = fopen("bacc/bacc.txt", "w+");

       if(t!=NULL)
        {
            for(i=0;i<nb-1;i++)
            {
                if(fprintf(t, "%s  %s  %d  %d  %d\n", tb[i].ncin, tb[i].seriebacc, tb[i].moyenne, tb[i].notemath, tb[i].notephy))
                {

                }
            }


        }
        else
        {
            printf("Erreur d'ouverture du fichier ! ");
            exit(1);

        }

    fclose(t);

    }



}


int resultat(char num())
{
    int nb=compter_ligne_bacc();
    int i=0;
    int j=0;
    int decision=0;
    Bacc tb[nb];
    Bacc b;


        FILE *f=NULL;

        f = fopen("bacc/bacc.txt", "r");

    if(f!=NULL)
    {
        while(fscanf(f, "%s  %s  %d  %d  %d\n", &b.ncin, &b.seriebacc, &b.moyenne, &b.notemath, &b.notephy ) !=EOF)
        {
            tb[i]=b;
            i=i+1;
        }


        for(i=0;i<nb;i++)
        {
            if(strcmp(tb[i].ncin, num)==0)
            {
                j=i;
                if(tb[i].moyenne>12)
                {
                    decision = 1;
                }
                else if(tb[i].moyenne<=12 && tb[i].moyenne>=11)
                {
                    float moymp = (tb[i].notemath+tb[i].notephy)/2;
                    if(moymp>=12)
                    {
                        decision = 1;
                    }
                    else
                        decision = 0;
                }
                else
                    decision = 0;
            }
        }

    }
    else
    {
        printf("\n ERREUR D'OUVERTURE DU FICHIER ! \n");
        exit(1);
    }

    return decision;

    fclose(f);
}




#endif // BACC_H_INCLUDED
