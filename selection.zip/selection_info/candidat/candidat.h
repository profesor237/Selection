#ifndef CANDIDAT_H_INCLUDED
#define CANDIDAT_H_INCLUDED
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "../bacc/bacc.h"
#include "../choix/choix.h"


typedef struct{

    char ncin[100];
    char nom[100];
    char prenom[100];
    int age;

} Candidat;




void affiche_candidat(Candidat c){

    printf("\n\n==============================================>");
    printf("\n Nom :  %s", c.nom);
    printf("\n Prenom : %s", c.prenom);
    printf("\n Age:  %d", c.age);
    printf("\n Numero CNI :  %s", c.ncin);
}

int compter_ligne_candidat()
{
        FILE *f=NULL;
    int i=0;
    Candidat c;
    Bacc b;
    f = fopen("candidat/candidat.txt", "r");
        while(fscanf(f, "%s  %s  %s  %d\n", &c.ncin, &c.nom, &c.prenom, &c.age) !=EOF)
        {
            i=i+1;
        }
    return i;
}


Candidat extraction_candidat(char num[100])
{
     int nb=compter_ligne_candidat();
    Candidat c, d;
    Candidat tc[nb];
    int i=0;
    int k=0;


    FILE *f=NULL;

    f = fopen("candidat/candidat.txt", "r");

    if(f!=NULL)
    {
        while(fscanf(f, "%s  %s  %s  %d\n", &c.ncin, &c.nom, &c.prenom, &c.age) !=EOF)
        {
            tc[i]=c;
            i=i+1;
        }

        for(k=0;k<nb;k++)
        {

            if(strcmp(tc[k].ncin, num)==0)
            {
                d=tc[k];

            }

        }

    }

    else{
        printf("\n ERREUR D'OUVERTURE DU FICHIER ! \n");
        exit(1);
    }

    return d;

    fclose(f);

}



void enregistrer_candidat(Candidat c)
{

    FILE *f=NULL;
    f = fopen("candidat/candidat.txt", "a");

    if(f!=NULL)
    {
        if(fprintf(f, "%s  %s  %s  %d\n", c.ncin, c.nom, c.prenom, c.age))
        {
            printf("\n\nLe candidat a bien ete enregistre ! ");

        }


    }

    else
    {
        printf("\n ERREUR D'OUVERTURE DU FICHIER ! \n");
        exit(1);
    }



    fclose(f);


}





void modifier_candidat(char anum[100], Candidat d)
{

    int nb=compter_ligne_candidat();
    int i=0;
    Candidat tc[nb];
    Candidat c;


        FILE *f=NULL;

        f = fopen("candidat/candidat.txt", "r");

    if(f!=NULL)
    {
        while(fscanf(f, "%s  %s  %s  %d\n", &c.ncin, &c.nom, &c.prenom, &c.age) !=EOF)
        {
            tc[i]=c;
            i=i+1;
        }


        for(i=0;i<nb;i++)
        {
            if(strcmp(tc[i].ncin, anum)==0)
            {
                tc[i]=d;
            }
        }


    }

    else{
        printf("\n ERREUR D'OUVERTURE DU FICHIER ! \n");
        exit(1);
    }



    fclose(f);


     FILE *t=NULL;
      t = fopen("candidat/candidat.txt", "w+");

       if(f!=NULL)
        {
            for(i=0;i<nb;i++)
            {
                if(fprintf(t, "%s  %s  %s  %d\n", tc[i].ncin, tc[i].nom, tc[i].prenom, tc[i].age))
                {

                }
            }


        }
        else
        {
            printf("Erreur d'ouverture du fichier ! ");
            exit(1);

        }

    fclose(t);

}






int verifier(char num[100])
{
    int i;
    int a=0;
    int nb=compter_ligne_candidat();
    Candidat c;
    Candidat tc[nb];

        FILE *f=NULL;

        f = fopen("candidat/candidat.txt", "r");

    if(f!=NULL)
    {
        while(fscanf(f, "%s  %s  %s  %d\n", &c.ncin, &c.nom, &c.prenom, &c.age) !=EOF)
        {
            tc[i]=c;
            i=i+1;
        }

        for(i=0;i<nb;i++)
        {
          if(strcmp(tc[i].ncin, num)== 0)
          {
              a = 1;
          }

        }

        return a;

    }

    else{
        printf("\n ERREUR D'OUVERTURE DU FICHIER ! \n");
        exit(1);
    }



    fclose(f);

}






void supprimer_candidat(char num[100])
{
    int nb=compter_ligne_candidat();
    int i=0;
    int j=0;
    Candidat tc[nb];
    Candidat c;


        FILE *f=NULL;

        f = fopen("candidat/candidat.txt", "r");

    if(f!=NULL)
    {
        while(fscanf(f, "%s  %s  %s  %d\n", &c.ncin, &c.nom, &c.prenom, &c.age) !=EOF)
        {
            tc[i]=c;
            i=i+1;
        }


        for(i=0;i<nb;i++)
        {
            if(strcmp(tc[i].ncin, num)==0)
            {

                j=i;
            }
        }

        for(i=0;i<nb;i++)
        {
            affiche_candidat(tc[i]);
        }

        if(j!=0)
        {
            printf("L'element se trouve dans le fichier");
                for(i=j;i<nb-1;i++)
                {
                    tc[i] = tc[i+1];
                }

        }
        else
        {
            printf("l'element ne se trouve pas dans le fichier");

        }
        for(i=0;i<nb-1;i++)
        {
            affiche_candidat(tc[i]);
        }

    }

    else{
        printf("\n ERREUR D'OUVERTURE DU FICHIER ! \n");
        exit(1);
    }

 fclose(f);
    if(j!=0)
    {


            FILE *t=NULL;
        t = fopen("candidat/candidat.txt", "w+");

        if(t!=NULL)
            {
                for(i=0;i<nb-1;i++)
                {
                    if(fprintf(t,"%s  %s  %s  %d\n", tc[i].ncin, tc[i].nom, tc[i].prenom, tc[i].age))
                    {

                    }
                }


            }
            else
            {
                printf("Erreur d'ouverture du fichier ! ");
                exit(1);

            }

        fclose(t);
    }





}

void enregistrer_resultat()
{
    int nb=compter_ligne_bacc();
    char nom[100];
    char num[100];
    float moy_gen, moy_mp;
    char decision[10];
    int j=0; int k=0;
    int i=0;
    Candidat tc[nb];
    Candidat c;
    Choix tch[nb];
    Choix ch;
    Bacc b;
    Bacc tb[nb];

       FILE *f=NULL;

        f = fopen("bacc/bacc.txt", "r");

        if(f!=NULL)
        {
            while(fscanf(f, "%s  %s  %d  %d  %d\n", &b.ncin, &b.seriebacc, &b.moyenne, &b.notemath, &b.notephy ) !=EOF)
            {
                tb[i] = b;
                i=i+1;

            }
        }

        else{
            printf("\n ERREUR D'OUVERTURE DU FICHIER ! \n");
            exit(1);
        }



        fclose(f);




   for(i=0;i<nb;i++)
    {

        strcpy(num, tb[i].ncin);

        c=extraction_candidat(num);
        tc[i]=c;
        tch[i] = extraction_choix(num);

    }


       FILE *t=NULL;

        t = fopen("resultat/resultat.txt", "w+");

        if(t!=NULL)
        {

            for(i=0;i<nb;i++)
                {

                    moy_mp=(tb[i].notemath+tb[i].notephy)/2;
                     strcpy(num, tb[i].ncin);
                    j=resultat(num);
                    if(j==1)
                        {strcpy(decision, tch[i].choix1);}
                    else
                        {strcpy(decision, tch[i].choix2);}

                   if(fprintf(t,"%s  %s  %s  %d  %f  %s\n ", tc[i].ncin, tc[i].nom, tc[i].prenom, tb[i].moyenne, moy_mp, decision))
                    {

                    }
                }

        }

        else{
            printf("\n ERREUR D'OUVERTURE DU FICHIER ! \n");
            exit(1);
        }



        fclose(t);


}

void enregistrer_admis()
{

    int nb=compter_ligne_candidat();
    char tnum[nb][100], td[nb][100];
    Candidat tc[nb], ca;
    char a[100], b[100], c[100], f[100];
    float d;
    char decision[100]="INFO";
    int e; int ni=0;
    int i=0;

    FILE *t=NULL;

        t = fopen("resultat/resultat.txt", "r");

        if(t!=NULL)
        {
            while(fscanf(t,"%s  %s  %s  %d  %f  %s\n ", &a, &b, &c, &d, &e, &f) !=EOF)
            {
                        strcpy(tnum[i], a);
                        strcpy(td[i], f);

                        i++;

            }


        }

        else{
            printf("\n ERREUR D'OUVERTURE DU FICHIER ! \n");
            exit(1);
        }



        fclose(t);

        for(i=0;i<nb;i++)
        {
            if(strcmp(td[i], decision)==0)
            {
                ni = ni+1;
                ca = extraction_candidat(tnum[i]);
                tc[i]=ca;

            }
        }

        char tca[ni][100];


                FILE *g=NULL;

                g = fopen("admis/admis.txt", "w+");

                if(g!=NULL)
                {

                for(i=0;i<ni;i++)
                {
                    if(fprintf(g,"%s  %s  %s  %d  %s \n ", tc[i].ncin, tc[i].nom, tc[i].prenom, tc[i].age, td[i]) )
                    {

                    }

                }


                }

                else{
                    printf("\n ERREUR D'OUVERTURE DU FICHIER ! \n");
                    exit(1);
                }
            fclose(g);

}

void selection()
{


    int nb=compter_ligne_candidat();
    char tnum[nb][100], td[nb][100];
    Candidat tc[nb], ca;
    char a[100], b[100], c[100], f[100];
    float d;
    char decision[100]="INFO";
    int e; int ni=0;
    int i=0;

    FILE *t=NULL;

        t = fopen("resultat/resultat.txt", "r");

        if(t!=NULL)
        {
            while(fscanf(t,"%s  %s  %s  %d  %f  %s\n ", &a, &b, &c, &d, &e, &f) !=EOF)
            {
                        strcpy(tnum[i], a);
                        strcpy(td[i], f);

                        i++;

            }


        }

        else{
            printf("\n ERREUR D'OUVERTURE DU FICHIER resultat ! \n");
            exit(1);
        }

        fclose(t);



         for(i=0;i<nb;i++)
        {
            if(strcmp(td[i], "CHIM")==0)
            {

                ca=extraction_candidat(tnum[i]);


                    FILE *g=NULL;

                    g = fopen("selection/chimie.txt", "w+");

                    if(g!=NULL)
                    {

                        for(i=0;i<ni;i++)
                        {
                            printf("le fichier est ouvert");
                            if(fprintf(g,"%s  %s  %s  %d  %s \n ", ca.ncin, ca.nom, ca.prenom, ca.age, td[i]) )
                            {

                            }

                        }


                    }

                else{
                        printf("\n ERREUR D'OUVERTURE DU FICHIER Chimie ! \n");
                        exit(1);
                    }
                    fclose(g);

            }


          /*  if(strcmp(td[i], "PHYS")==0)
            {

                    ca=extraction_candidat(tnum[i]);


                    FILE *h=NULL;

                    h = fopen("selection/physique.txt", "w+");

                    if(h!=NULL)
                    {

                        for(i=0;i<ni;i++)
                        {
                            if(fprintf(h,"%s  %s  %s  %d  %s \n ", ca.ncin, ca.nom, ca.prenom, ca.age, td[i]) )
                            {

                            }

                        }


                    }

                else{
                        printf("\n ERREUR D'OUVERTURE DU FICHIER physique! \n");
                        exit(1);
                    }
                    fclose(h);


            }


            if(strcmp(td[i], "MATH")==0)
            {

                    ca=extraction_candidat(tnum[i]);


                    FILE *j=NULL;

                    j = fopen("selection/mathematique.txt", "w+");

                    if(j!=NULL)
                    {

                        for(i=0;i<ni;i++)
                        {
                            if(fprintf(j,"%s  %s  %s  %d  %s \n ", ca.ncin, ca.nom, ca.prenom, ca.age, td[i]) )
                            {

                            }

                        }


                    }

                else{
                        printf("\n ERREUR D'OUVERTURE DU FICHIER mathematique ! \n");
                        exit(1);
                    }
                    fclose(j);

            }


            if(strcmp(td[i], "BIOS")==0)
            {

                    ca=extraction_candidat(tnum[i]);


                    FILE *k=NULL;

                    k = fopen("selection/bioscience.txt", "w+");

                    if(k!=NULL)
                    {

                        for(i=0;i<ni;i++)
                        {
                            if(fprintf(k,"%s  %s  %s  %d  %s \n ", ca.ncin, ca.nom, ca.prenom, ca.age, td[i]) )
                            {

                            }

                        }                    ca=extraction_candidat(tnum[i]);


                    FILE *k=NULL;

                    k = fopen("selection/bioscience.txt", "w+");

                    if(k!=NULL)
                    {

                        for(i=0;i<ni;i++)
                        {
                            if(fprintf(k,"%s  %s  %s  %d  %s \n ", ca.ncin, ca.nom, ca.prenom, ca.age, td[i]) )
                            {

                            }

                        }


                    }

                else{
                        printf("\n ERREUR D'OUVERTURE DU FICHIER ! \n");
                        exit(1);
                    }
                    fclose(k);


                    }

                else{
                        printf("\n ERREUR D'OUVERTURE DU FICHIER Bioscience! \n");
                        exit(1);
                    }
                    fclose(k);
            }


             if(strcmp(td[i], "GEOS")==0)
             {

                                        ca=extraction_candidat(tnum[i]);


                    FILE *l=NULL;

                    l = fopen("selection/geoscience.txt", "w+");

                    if(l!=NULL)
                    {

                        for(i=0;i<ni;i++)
                        {
                            if(fprintf(l,"%s  %s  %s  %d  %s \n ", ca.ncin, ca.nom, ca.prenom, ca.age, td[i]) )
                            {

                            }

                        }


                    }

                else{
                        printf("\n ERREUR D'OUVERTURE DU FICHIER Geoscience! \n");
                        exit(1);
                    }
                    fclose(l);

             }*/

        }
}


#endif // CANDIDAT_H_INCLUDED
