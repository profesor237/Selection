#if !defined(__CLIENT__)
#define __CLIENT__
#include <list>
#include <string>
#include <iomanip>		// inclure le setw
#include "../Commandes/commande.h"
#include "../Articles/article.h"
#include "../Clients/client.h"
#include <stdlib.h>

using namespace std;

class Commande;		// pour pouvoir compiler la declaration de la class Commande
class Client
{
public:
	Client();										//constructeur par defaut
	Client(int, string, string, string, char);		// constructeur avec parametre
	void setnumero(int);
	int getnumero();
	void setnom(string);
	string getnom();
	void setprenom(string);
	string getprenom();
	void setdate(string);
	string getdate();
	void setgenre(char);
	char getgenre();
	void show_client();

private:
	int numero;
	string nom;
	string prenom;
	string date;
	char genre;
};
Client::Client()
{};
Client::Client(int num, string n, string p, string d, char g)
{
	numero = num;
	nom = n;
	prenom = p;
	date = d;
	genre = g;
}
void Client::setnumero(int q)
{
	numero = q;
}
int Client::getnumero()
{
	return numero;
}
void Client::setnom(string n)
{
	nom = n;
}
string Client::getnom()
{
	return nom;
}
void Client::setprenom(string p)
{
	prenom = p;
}
string Client::getprenom()
{
	return prenom;
}
void Client::setdate(string d)
{
	date = d;
}
string Client::getdate()
{
	return date;
}

void Client::setgenre(char c)
{
	genre = c;
}
char Client::getgenre()
{
	return genre;
}

void Client::show_client()
{
	cout << "Le client est representer par : \n Le numero du client est :  " << numero << "\n Son nom est : "<< nom << "\n Son prenom est : "<< prenom << "\n Sa date de naissance est : " << date << "\n son genre est : " << genre <<"\n";
}


//		Definition des autres fonctions membres

void choix_client();
void menu2();
void choix_client1();
void choix_client2();
void choix_client3();
void choix_client4();
void choix_client5();
void choix_client6();


int nombre_ligne_fichier_client()
{
	int n=0;
	ifstream flux_client("C:/MesFichiersC++/Supermaket/Fichier_Client.txt", ios::in);
	string ligne;
    while(getline(flux_client, ligne))
    {
        n++;
    }
    flux_client.close();
	return n;
}

//--------creation d'une liste chainees

// recherche d'une valeur dans une lise chainee

bool list_find_client(list<int> l, int val)
{
	for(list<int>::iterator it = l.begin(); it!=l.end();++it)
	{
		if(*it == val)
			return 1;
	}
	return 0;
}
// Fonction de copie du contenue d'un fichier dans un tableau
Client *copy_client_file()        // represente la taille du tableau
{
    Client *tab = new Client[100];
	ifstream flux_client("C:/MesFichiersC++/Supermaket/Fichier_Client.txt" , ios::in);
	int taille = nombre_ligne_fichier_client();

    for(int j=0;j<=taille;j++)
    {
        int num; string n,p,d; char g;
        flux_client >> num >> n >> p >> d>>g;

    // j'imprime toutes la liste dans un tableau de client

        tab[j].setnumero(num);
        tab[j].setnom(n);
        tab[j].setprenom(p);
        tab[j].setdate(d);
        tab[j].setgenre(g);
	}
	flux_client.close();
	return tab;
}

//----------insertion des valeurs d'une liste dans le fichier

int recherche_liste_client_numero(int val)
{
    Client *liste_client = copy_client_file();      // liste des clients du fichier
    int n = nombre_ligne_fichier_client();          // nombre de ligne du fichier et qui representera la taille du tableau

    for (int i=0; i<n ; i++)
    {
        if (liste_client[i].getnumero()==val)
            return i;
    }
    return -1;
}

int recherche_liste_client_nom(string nom)             //recherche en fonction du nom du client
{
    Client *liste_client = copy_client_file();      // liste des clients du fichier
    int n = nombre_ligne_fichier_client();          // nombre de ligne du fichier et qui representera la taille du tableau

    for (int i=0; i<n ; i++)
    {
        if (liste_client[i].getnom()==nom)
            return i;
    }
    return -1;
}

int recherche_liste_client_prenom(string prenom)             // recherche en fonction du prenom du client
{
    Client *liste_client = copy_client_file();      // liste des clients du fichier
    int n = nombre_ligne_fichier_client();          // nombre de ligne du fichier et qui representera la taille du tableau

    for (int i=0; i<n ; i++)
    {
        if (liste_client[i].getprenom()==prenom)
            return i;
    }
    return -1;
}

int recherche_liste_client_date(string date)
{
    Client *liste_client = copy_client_file();      // liste des clients du fichier
    int n = nombre_ligne_fichier_client();          // nombre de ligne du fichier et qui representera la taille du tableau

    for (int i=0; i<n ; i++)
    {
        if (liste_client[i].getdate()==date)
            return i;
    }
    return -1;
}

int recherche_liste_client_genre(char sexe)
{
    Client *liste_client = copy_client_file();      // liste des clients du fichier
    int n = nombre_ligne_fichier_client();          // nombre de ligne du fichier et qui representera la taille du tableau

    for (int i=0; i<n ; i++)
    {
        if (liste_client[i].getgenre()==sexe)
            return i;
    }
    return -1;
}



void Enregistrer_client(Client client)
{
	int taille;
	list<int> liste_num_client;				// stocke less dentifiant de chaque client (numero)
	ifstream flux_client("C:/MesFichiersC++/Supermaket/Fichier_Client.txt" , ios::in);

	taille = nombre_ligne_fichier_client();
    Client tab[taille+1];
    for(int j=0;j<=taille;j++)
    {
        int num; string n,p,d; char g;
        flux_client >> num >> n >> p >> d>>g;

        liste_num_client.push_back(num);        // je met le numero du client dans la liste chainee
        // j'imprime toutes la liste dans un tableau de client

        tab[j].setnumero(num);
        tab[j].setnom(n);
        tab[j].setprenom(p);
        tab[j].setdate(d);
        tab[j].setgenre(g);
        cout << "\n\nLe liste de vos client contenu dans le fichier est : \n";
        for(int i=0;i<j;i++)
        {
            tab[i].show_client();
        }

        cout << "nombre de clients present dans le fichier : " << j <<" client(s) \n";
            //j'insert le numero du client j dans la liste chainee de numero
    }

	flux_client.close();

	ofstream flux_client_sortie("C:/MesFichiersC++/Supermaket/Fichier_Client.txt", ios::app);
	if (taille == 0)
    {
        cout << "Le fichier etait vide\n\n";
        flux_client_sortie << client.getnumero() <<"\t" << client.getnom()<<"\t"<<client.getprenom()<<"\t"<<client.getdate()<<"\t" << client.getgenre();
    }
    else
    {
        if (list_find_client(liste_num_client,client.getnumero()))				// je verifie que le numero a entre ne se trouve pas dans la liste chainee
        {
            cout << "Impossible d'inserer ce client sous ce numero, car il a deja ete enregistre a un autre client \n";
        }
        else
        {
            flux_client_sortie <<"\n" << client.getnumero()<<"\t"<< client.getnom() << "\t"<< client.getprenom() << "\t" << client.getdate() <<"\t"<< client.getgenre();
        }
    }
    flux_client_sortie.close();
}

void insertion_fichier(Client *cl, int n)
{
    ofstream fichier_client("C:/MesFichiersC++/Supermaket/Fichier_Client.txt");
    for(int i=0;i<n;i++)
    {
        Enregistrer_client(cl[i]);
    }
}

/* Fonction qui permet de modifier une information dans le fichier client */

/*void modifier_client(int ancien, int nouveau)
{
    Client *liste_client = copy_client_file();      // liste des clients du fichier
    int n = nombre_ligne_fichier_client();
    int indice = recherche_liste_client_numero(ancien);
    if (indice != -1)
    {
        liste_client[indice].setnumero(nouveau);
        insertion_fichier(liste_client, n);
    }
    else
        cout << "\nLe fichier ne contient pas ce numero\n";

}*/

void modifier_client(int ancien, int nouveau, string no, string pren, string d, char g)
{
    Client *liste_client = copy_client_file();      // liste des clients du fichier
    int n = nombre_ligne_fichier_client();
    int indice = recherche_liste_client_numero(ancien);
    if (indice != -1)
    {
        liste_client[indice].setnumero(nouveau);
        liste_client[indice].setnom(no);
        liste_client[indice].setprenom(pren);
        liste_client[indice].setdate(d);
        liste_client[indice].setgenre(g);
        insertion_fichier(liste_client, n);
    }
    else
        cout << "\nLe fichier ne contient pas ce numero\n";

}

/*----Fonction de suppression dans le fichier client---------*/

void supprime_client(int num)
{
    Client *liste_client = copy_client_file();
    int indice = recherche_liste_client_numero(num);
    int n = nombre_ligne_fichier_client();
    if(indice != -1)
    {
        for(int i=indice; i<n-1;i++)
        {
            liste_client[i]=liste_client[i+1];
        }
        insertion_fichier(liste_client, n-1);
    }
    else
        cout << "\nLe fichier ne contient pas ce numero\n";

}

void Affiche_Clients()
{
	Client *tab = copy_client_file();
	const int NMAX = nombre_ligne_fichier_client() ; // nombre de valeurs
	int i, j ;

	/* affichage ligne en-tête */
	cout << "      |" ;
	cout << setw(10) << "Numero" ;
	cout << setw(10) << "Noms" ;
	cout << setw(10) << "Prenom" ;
	cout << setw(10) << "Date" ;
	cout << setw(10) << "Genre" ;

	cout << "\n" ;
	cout <<"-------" ;
	for (j=1 ; j<=5 ; j++) cout << "----------" ;
	cout << "\n" ;

	/* affichage des différentes lignes */
	for (i=1 ; i<=NMAX ; i++)
	{
		cout << setw(5) << i << " |" ;
		for (j=1 ; j<=NMAX ; j++)
			cout << setw(10) << tab[i].getnumero() ;
			cout << setw(10) << tab[i].getnom() ;
			cout << setw(10) << tab[i].getprenom() ;
			cout << setw(10) << tab[i].getdate() ;
			cout << setw(10) << tab[i].getgenre() ;

		cout << "\n" ;
	}
}

void liste_commande_du_client(int num)
{
	int indexe = recherche_liste_commande_num_client(num);
	if (indexe != -1)
	{
		cout << "La commande du client de numero " << num << "est :\n";
		Commande *cmd = copy_commande_file();
		cmd[indexe].show_commande();
	}
	else
		cout << "Aucune commande n'est enregistre pour ce client\n";
}

void entete2()
{
    cout << "\n\n\n\n";
    cout <<"                        ********************************************************** \n";
    cout <<"                        *                                                        * \n";
    cout <<"                        *              SUPER MARCHE EMERGENCE +++                * \n";
    cout <<"                        *                                                        * \n";
    cout <<"                        *                                                        * \n";
    cout <<"                        ********************************************************** \n\n\n\n";
}

void menu2()
{
    int n;
    system("CLS");
    entete2();
    cout << " Choisissez une action a effectuer : \n";
    cout <<"_________________________________________________________________ \n\n";
    cout <<"1- Gestion des articles \n";
    cout <<"2- Gestion des clients   \n";
    cout <<"3- Gestion des commandes \n";
    cout <<"4- Gestion des livraisons \n";
    cout <<"5- Calculer le capital du supermarche \n\n";
    cout <<"_________________________________________________________________ \n\n";
    cout <<"    Votre choix : " <<endl; cin >> n;

   if(n == 1)
       choix_article();
     if(n==2)
        choix_client();
    else if (n==3)
       choix_commande();
    else if (n==4)
        choix_livraison();
    //else if (n==5)
       // choix_capital();
    else
    {
        system("CLS");
        entete2();
       cout << " \n\n\n\n                                CHOIX INDISPONIBLE.....\n\n\n\n\n";
       system("PAUSE");
       menu2();
    }


}

void recherche_client()
{
    int choix;
    system("CLS");
    entete2();
    cout << "                       --------------------------------------- \n";
    cout << "                              RECHERCHE D'UN CLIENT   \n";
    cout << "                       ---------------------------------------  \n\n";
    cout << "Voulez vous chercher le client en fonction quoi? \n\n" ;
    cout << "__________________________________________________________________________________________\n\n";
    cout << "       1-Numero du client\n";
    cout << "       2-Nom du client\n";
    cout << "       3-Prenom du client\n";
    cout << "       4-Date de naissance du client\n";
    cout << "       5-Genre ou sexe du client\n\n";
    cout << "       6-RETOUR \n\n";
    cout << "__________________________________________________________________________________________\n\n";
    cout << "                Votre choix : ";   cin >> choix;

    if (choix == 1)
    {
        int val;
        system("CLS");
        entete2();
        cout << "                       ----------------------------------------------------\n";
        cout << "                          RECHERCHE D'UN CLIENT EN FONCTION DE SON NUMERO   \n";
        cout << "                       ----------------------------------------------------  \n\n";
        cout << " Entrez le numero du client que vous souhaitez rechercher : " ; cin >> val;
        recherche_liste_client_numero(val);
        system("PAUSE");
        system("CLS");
        recherche_client();
    }

    if (choix == 2)
    {
        string val;
        system("CLS");
        entete2();
        cout << "                       ----------------------------------------------------\n";
        cout << "                            RECHERCHE D'UN CLIENT EN FONCTION DU NOM  \n";
        cout << "                       ----------------------------------------------------  \n\n";
        cout << " Entrez le nOM du client que vous souhaitez rechercher : " ; cin >> val;
        recherche_liste_client_nom(val);
        system("PAUSE");
        system("CLS");
        recherche_client();
    }
    if(choix==3)
    {
        string val;
        system("CLS");
        entete2();
        cout << "                       ----------------------------------------------------\n";
        cout << "                            RECHERCHE D'UN CLIENT EN FONCTION DU PRENOM  \n";
        cout << "                       ----------------------------------------------------  \n\n";
        cout << " Entrez le prenom du client que vous souhaitez rechercher : " ; cin >> val;
        recherche_liste_client_prenom(val);
        system("PAUSE");
        system("CLS");
        recherche_client();
    }
    if(choix==4)
    {
        string val;
        system("CLS");
        entete2();
        cout << "                       ----------------------------------------------------------------------\n";
        cout << "                            RECHERCHE D'UN CLIENT EN FONCTION DE LA DATE DE NAISSANCE        \n";
        cout << "                       ----------------------------------------------------------------------  \n\n";
        cout << " Entrez le date de naissance du client que vous souhaitez rechercher : " ; cin >> val;
        recherche_liste_client_date(val);
        system("PAUSE");
        system("CLS");
        recherche_client();
    }
    if(choix==5)
    {
        char val;
        cout << "                       -----------------------------------------------------------\n";
        cout << "                            RECHERCHE D'UN CLIENT EN FONCTION DE SON GENRE        \n";
        cout << "                       -----------------------------------------------------------\n\n";
        cout << " Entrez le date de naissance du client que vous souhaitez rechercher : " ; cin >> val;
        recherche_liste_client_genre(val);
        system("PAUSE");
        system("CLS");
        recherche_client();
    }
    if(choix==6)
    {
        system("CLS");
        choix_client();
    }
    else
    {
        system("CLS");
        entete2();
        cout << "\n\n\n\n\n                  CHOIX INDISPONIBLE......\n\n\n\n";
        system("PAUSE");
        recherche_client();
    }
}

void choix_client()
{
    int t;
    system("CLS");
    entete2();
    cout << "                           --------------------------------------------------------------\n";
    cout << "                                BIENVENUE DANS LE SYSTEME DE GESTION DES CLIENTS        \n";
    cout << "                           -------------------------------------------------------------- \n\n\n";
    cout << " Choisissez une action a effectuer : \n";
    cout <<"_________________________________________________________________ \n\n\n";
    cout <<"1- Enregistrer un client\n";
    cout <<"2- Rechercher un client\n";
    cout <<"3- Modifier un client \n";
    cout <<"4- Supprimer un client \n";
    cout <<"5- Lister les clients d'un article specifique \n";
    cout <<"6- Connaitre le meilleur client du SUPER MARCHE en fonction d'un article \n\n";
    cout <<"7- RETOUR \n\n";
    cout <<"_________________________________________________________________ \n\n\n";
    cout << "              Votre choix : "; cin >>t;

    if (t==1)
        choix_client1();
    else if (t==2)
        choix_client2();
    else if (t==3)
        choix_client3();
    else if(t==4)
        choix_client4();
    else if (t==5)
        choix_client5();
    else if(t==6)
        choix_client6();
    else if (t==7)
    {
        system("CLS");
        menu2();
    }
    else
    {
        cout << " \n\nChoix indisponible.....\n\n";
       system("PAUSE");
       choix_client();
    }

}

void choix_client1()
{
    int n;
    Client tab[100];
    system("CLS");
    entete2();
    cout << "                       ------------------------------\n";
    cout << "                         ENREGISTREMENT DES CLIENT   \n";
    cout << "                       ------------------------------  \n\n";
    cout << " Combien de clients voulez vous enregistrer ?    ";
    cin >> n;
    for(int i=0;i<n;i++)
    {
        int nu; string nom, prenom, date; char g;
        cout << "   -Enregistrement du client numero " << i+1 << endl;
        cout << "   -Numero du client :  "; cin >> nu;
        cout << "   -Nom : "; cin >>nom;
        cout << "   -Prenom : "; cin >> prenom;
        cout << "   -Date de naissance (jj-mm-aa) : "; cin >>date;
        cout << "   -Genre :  " ; cin >> g; cout << "\n\n";
        tab[i].setnumero(nu); tab[i].setnom(nom); tab[i].setprenom(prenom); tab[i].setgenre(g); tab[i].setdate(date);
        Enregistrer_client(tab[i]);

    }
    system("PAUSE");
    system("CLS");
    choix_client();
}

void choix_client2()
{
    recherche_client();
    string c;
    cout << " \n\n Voulez vous retourner a la page precedente ? O/N  "; cin >> c;
    if (c=="O" || c=="o"|| c=="OUI"||c=="oui")
    {
        system("CLS");
        choix_client();
    }
    else
    {
        system("CLS");
        choix_client2();
    }
}

void choix_client3()
{
    int nu, anu, nnu;
    string nnom, nprenom, ndate;
    char ng;
    Client tab[100];
    system("CLS");
    entete2();
    cout << "                       --------------------------------------- \n";
    cout << "                              MODIFICATION D'UN CLIENT   \n";
    cout << "                       ---------------------------------------  \n\n";
    cout << "Entrez le numero du client que vous souhaitez modifier :  "; cin >> nu;
    cout << " Entrez les nouvelles informations sur le client : \n";
    cout << "    -Numero : "; cin >> nnu;
    cout <<"     -Nom : "; cin >> nnom;
    cout << "    -Prenom "; cin >> nprenom;
    cout << "    -Date : "; cin >> ndate;
    cout << "    -Genre : "; cin >> ng;
    modifier_client(nu, nnu, nnom, nprenom, ndate, ng);
    system ("PAUSE");
    system("CLS");
    choix_client();
}
void choix_client4()
{
    int nu;
    system("CLS");
    entete2();
    cout << "                       --------------------------------------- \n";
    cout << "                               SUPPRESSION D'UN CLIENT         \n";
    cout << "                       ---------------------------------------  \n\n";
    cout << "Entrez le numero du client que vous souhaitez supprimer :  "; cin >> nu;
    supprime_client(nu);
    system ("PAUSE");
    system("CLS");
    choix_client();

}
void choix_client5()
{
    int nu;
    system("CLS");
    entete2();
    cout << "                       --------------------------------------- \n";
    cout << "                         LISTE DES CLIENTS D'UN ARTICLE        \n";
    cout << "                       ---------------------------------------  \n\n";
    cout << "Entrez la reference de l'article dont vous souhaitez connaitre les clients :  "; cin >> nu;

}
void choix_client6()
{
    int nu;
   system("CLS");
   entete2();
    cout << "                      --------------------------------------- \n";
    cout << "                          LE MEILLEUR CLIENT D'UN ARTICLE   \n";
    cout << "                      ---------------------------------------  \n\n";
    cout << "Entrez la reference du produit dont vous voulez connaitre le meilleur client:  "; cin >> nu;
}
#endif
