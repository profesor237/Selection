#if !defined(__LIVRAISON__)
#define __LIVRAISON__

#include <iostream>
#include <string>
#include "../Clients/client.h"
#include "../Commandes/commande.h"
#include "../Articles/article.h"
#include <stdlib.h>

using namespace std;

class Livraison
{
private:
	int numero_commande;
	int quantite;
	int numero_client;
	string refer_article;
public:
	Livraison();
	Livraison(int, int, int, string);
	void set_numero_commande(int);
	int get_numero_commande();
	void set_quantite(int);
	int get_quantite();
	void set_numero_client(int);
	int get_numero_client();
	void show_livraison();
	void set_refer_article(string);
	string get_refer_article();
};

Livraison::Livraison()
{
	numero_commande = 0;
	quantite =0;
	numero_client = 0;
	refer_article = "";
}
Livraison::Livraison(int num_cmd, int q, int num_client, string ref)
{
	numero_commande = num_cmd;
	quantite = q;
	numero_client = num_client;
	refer_article = ref;
}
void Livraison::set_numero_commande(int num_cmd)
{
	numero_commande = num_cmd;
}
int Livraison::get_numero_commande()
{
	return numero_commande;
}
void Livraison::set_quantite(int q)
{
	quantite = q;
}
int Livraison::get_quantite()
{
	return quantite;
}
void Livraison::set_numero_client(int num_client)
{
	numero_client = num_client;
}
int Livraison::get_numero_client()
{
	return numero_client;
}
void Livraison::set_refer_article(string ref)
{
	refer_article = ref;
}
string Livraison::get_refer_article()
{
	return refer_article;
}
void Livraison::show_livraison()
{
	cout << "La livraison est : \n Numero de la commande : "<< numero_commande << "\n L'article a live est : " << refer_article << " \n La quantite a livre est : " << quantite << "\n le numero du client est : " << numero_client <<"\n";
}

void menu4();
void entete4();
void choix_article();
void choix_client();
void choix_commande();


int nombre_ligne_fichier_livraison()
{
	int n=0;
	ifstream flux_livraison("C:/MesFichiersC++/Supermaket/Livraisons/Fichier_Livraison.txt", ios::in);
	string ligne;
    while(getline(flux_livraison, ligne))
    {
        n++;
        cout << "ligne numero :"<<n;
    }
    flux_livraison.close();
	return n;
}

//--------creation d'une liste chainees

// recherche d'une valeur dans une lise chainee

bool list_find_art(list<int> l, int val)
{
	for(list<int>::iterator it = l.begin(); it!=l.end();++it)
	{
		if(*it == val)
			return 1;
	}
	return 0;
}
// Fonction de copie du contenue d'un fichier dans un tableau
Livraison *copy_livraison_file()        // represente la taille du tableau
{
    Livraison *tab = new Livraison[100];
	ifstream flux_livraison("C:/MesFichiersC++/Supermaket/Livraisons/Fichier_Livraison.txt" , ios::in);
	int taille = nombre_ligne_fichier_livraison();

    for(int j=0;j<=taille;j++)
    {
        int num_cmd, qt, num_cl; string ref_art;
        flux_livraison >> num_cmd >> num_cl >> qt >> ref_art;

    // j'imprime toutes la liste dans un tableau de client

        tab[j].set_numero_commande(num_cmd);
        tab[j].set_quantite(qt);
        tab[j].set_numero_client(num_cl);
        tab[j].set_refer_article(ref_art);
	}
	flux_livraison.close();
	return tab;
}

//----------insertion des valeurs d'une liste dans le fichier

int recherche_liste_livraison_numero_commande(int val)
{
    Livraison *liste_livraison = copy_livraison_file();      // liste des clients du fichier
    int n = nombre_ligne_fichier_livraison();          // nombre de ligne du fichier et qui representera la taille du tableau

    for (int i=0; i<n ; i++)
    {
        if (liste_livraison[i].get_numero_commande()==val)
            return i;
    }
    return -1;
}

int recherche_liste_client_quantite(int q)             //recherche en fonction du nom du client
{
    Livraison *liste_livraison = copy_livraison_file();      // liste des clients du fichier
    int n = nombre_ligne_fichier_livraison();          // nombre de ligne du fichier et qui representera la taille du tableau

    for (int i=0; i<n ; i++)
    {
        if (liste_livraison[i].get_quantite()==q)
            return i;
    }
    return -1;
}

int recherche_liste_client_numero_client(int num_cl)             // recherche en fonction du prenom du client
{
    Livraison *liste_livraison = copy_livraison_file();      // liste des clients du fichier
    int n = nombre_ligne_fichier_livraison();          // nombre de ligne du fichier et qui representera la taille du tableau

    for (int i=0; i<n ; i++)
    {
        if (liste_livraison[i].get_numero_client()==num_cl)
            return i;
    }
    return -1;
}

int recherche_liste_client_reference_article(string ref_art)
{
    Livraison *liste_livraison = copy_livraison_file();      // liste des clients du fichier
    int n = nombre_ligne_fichier_livraison();          // nombre de ligne du fichier et qui representera la taille du tableau

    for (int i=0; i<n ; i++)
    {
        if (liste_livraison[i].get_refer_article()==ref_art)
            return i;
    }
    return -1;
}



void Enregistrer_livraison(Livraison livraison)
{
	int taille;
	list<int> liste_num_cmd;				// stocke less dentifiant de chaque client (numero)
	ifstream flux_livraison("C:/MesFichiersC++/Supermaket/Livraisons/Fichier_Livraison.txt" , ios::in);

	taille = nombre_ligne_fichier_livraison();
    Livraison tab[taille+1];
    for(int j=0;j<=taille;j++)
    {
        int num_cmd, qt, num_cl; string ref_art;
        flux_livraison >> num_cmd >> num_cl >> qt >> ref_art;

        liste_num_cmd.push_back(num_cmd);        // je met le numero du client dans la liste chainee

    // j'imprime toutes la liste dans un tableau de client

        tab[j].set_numero_commande(num_cmd);
        tab[j].set_quantite(qt);
        tab[j].set_numero_client(num_cl);
        tab[j].set_refer_article(ref_art);

        cout << "\n\nLe liste de vos client contenu dans le fichier est : \n";
        for(int i=0;i<j;i++)
        {
            tab[i].show_livraison();
        }

        cout << "nombre de livraisons present dans le fichier : " << j <<" livraison(s) \n";
            //j'insert le numero du client j dans la liste chainee de numero
    }

	flux_livraison.close();

	ofstream flux_livraison_sortie("C:/MesFichiersC++/Supermaket/Livraisons/Fichier_Livraison.txt", ios::app);
	if (taille == 0)
    {
        cout << "Le fichier etait vide\n\n";
        flux_livraison_sortie << livraison.get_numero_commande() <<"\t" << livraison.get_quantite()<<"\t"<<livraison.get_numero_client()<<"\t"<<livraison.get_refer_article();
    }
    else
    {
        if (list_find_art(liste_num_cmd,livraison.get_numero_commande()))				// je verifie que le numero a entre ne se trouve pas dans la liste chainee
        {
            cout << "Impossible d'inserer cette livraison sous ce numero, car il a deja ete enregistre a un autre livraison \n";
        }
        else
        {
            flux_livraison_sortie <<"\n" << livraison.get_numero_commande()<<"\t"<< livraison.get_quantite() << "\t"<< livraison.get_numero_client() << "\t" << livraison.get_refer_article() ;
        }
    }
    flux_livraison_sortie.close();
}

void insertion_fichier_livraison(Livraison *lv, int n)
{
    ofstream Fichier_Livraison("C:/MesFichiersC++/Supermaket/Livraisons/Fichier_Livraison.txt");
    for(int i=0;i<n;i++)
    {
        Enregistrer_livraison(lv[i]);
    }
}

/* Fonction qui permet de modifier une information dans le fichier client */

void modifier_livraison(int ancien, int nouveau)
{
    Livraison *liste_livraison = copy_livraison_file();      // liste des clients du fichier
    int n = nombre_ligne_fichier_livraison();
    int indice = recherche_liste_livraison_numero_commande(ancien);
    if (indice != -1)
    {
        liste_livraison[indice].set_numero_commande(nouveau);
        insertion_fichier_livraison(liste_livraison, n);
    }
    else
        cout << "\nLe fichier ne contient pas ce numero\n";

}

/*----Fonction de suppression dans le fichier client---------*/

void supprime_livraison(int num)
{
    Livraison *liste_livraison = copy_livraison_file();
    int indice = recherche_liste_livraison_numero_commande(num);
    int n = nombre_ligne_fichier_livraison();
    if(indice != -1)
    {
        for(int i=indice; i<n-1;i++)
        {
            liste_livraison[i]=liste_livraison[i+1];
        }
        insertion_fichier_livraison(liste_livraison, n-1);
    }
    else
        cout << "\nLe fichier ne contient pas ce numero\n";

}
void entete4()
{
    cout << "\n\n\n\n";
    cout <<"                        ********************************************************** \n";
    cout <<"                        *                                                        * \n";
    cout <<"                        *              SUPER MARCHE EMERGENCE +++                * \n";
    cout <<"                        *                                                        * \n";
    cout <<"                        *                                                        * \n";
    cout <<"                        ********************************************************** \n\n\n\n";
}
recherche_livraison()
{
    int choix;
    system("CLS");
    entete4();
    cout << "                       --------------------------------------- \n";
    cout << "                              RECHERCHE D'UNE LIVRAISON   \n";
    cout << "                       ---------------------------------------  \n\n";
    cout << "Voulez vous chercher la livraison en fonction de quoi ? \n" ;
    cout << "_______________________________________________________________________________________________\n\n";
    cout << "       1-Numero de la commande \n";
    cout << "       2-Numero du client\n";
    cout << "       3-La reference de l'article\n";
    cout << "       4-Quantite d'article\n\n";
    cout << "       5-RETOUR\n\n";
    cout << "_______________________________________________________________________________________________\n\n";
    cout << "                         Votre choix : "; cin >> choix;

    if (choix == 3)
    {
        string val;
        system("CLS");
        entete4();
        cout << "                       ------------------------------------------------------------------\n";
        cout << "                          RECHERCHE D'UNE LIVRAISON EN FONCTION LA REFERENCE DU PRODUIT   \n";
        cout << "                       ------------------------------------------------------------------  \n\n";
        cout << " Entrez la reference de l'article concernee par la livraison que vous souhaitez rechercher : " ; cin >> val;
        recherche_liste_client_reference_article(val);
        system("PAUSE");
        recherche_livraison();
    }

    if (choix == 1)
    {
        int val;
        system("CLS");
        entete4();
        cout << "                       ------------------------------------------------------------------\n";
        cout << "                            RECHERCHE D'UNE LIVRAISON EN FONCTION DU NUMERO DE COMMANDE  \n";
        cout << "                       ------------------------------------------------------------------  \n\n";
        cout << " Entrez le numero de la commande concernee par la livraison que vous souhaitez rechercher : " ; cin >> val;
        recherche_liste_livraison_numero_commande(val);
        system("PAUSE");
        recherche_livraison();
    }
    if(choix==2)
    {
        int val;
        system("CLS");
        entete4();
        cout << "                       -----------------------------------------------------------\n";
        cout << "                          RECHERCHE D'UNE LIVRAISON EN FONCTION DU NUMERO CLIENT  \n";
        cout << "                       -----------------------------------------------------------  \n\n";
        cout << " Entrez le numero du client concerne par cette livraison que vous souhaitez rechercher : " ; cin >> val;
        recherche_liste_client_numero_client(val);
        system("PAUSE");
        recherche_livraison();
    }
    if(choix==4)
    {
        int q;
        system("CLS");
        entete4();
        cout << "                       ----------------------------------------------------------------------\n";
        cout << "                            RECHERCHE D'UNE LIVRAISON EN FONCTION DE LA QUANTITE COMMANDE       \n";
        cout << "                       ----------------------------------------------------------------------  \n\n";
        cout << " Entrez la quantite de commande concernee par la livraison que vous souhaitez rechercher : " ; cin >> q;
        recherche_liste_client_quantite(q);
        system("PAUSE");
        recherche_livraison();
    }
    else if(choix==5)
    {


        system("CLS");
        entete4();
       cout << " \n\n\n\n                   CHOIX INDISPONIBLE.....\n\n\n\n";
       system("PAUSE");
       menu4();

    }
    else
    {
        system("CLS");
        entete4();
        cout << "\n\n\n\n\n                  CHOIX INDISPONIBLE......\n\n\n\n";
        system("PAUSE");
        recherche_livraison();
    }
}


void choix_livraison()
{
    system("CLS");
    entete4();
    cout << "                            ----------------------------------------------------------\n";
    cout << "                                BIENVENUE DANS LE SYSTEME DE GESTION DES LIVRAISONS    \n";
    cout << "                            ---------------------------------------------------------- \n\n\n";
    cout << " Choisissez une action a effectuer : \n";
    cout <<"_________________________________________________________________ \n\n\n";
    cout <<"1- Enregistrer une livraison\n";
    cout <<"2- Modifier une livraison \n";
    cout <<"3- Supprimer une livraison \n\n";
    cout <<"_________________________________________________________________ \n\n\n";

}


void menu4()
{
    int n;
    system("CLS");
    entete4();
    cout << " Choisissez une action a effectuer : \n";
    cout <<"_________________________________________________________________ \n\n";
    cout <<"1- Gestion des articles \n";
    cout <<"2- Gestion des clients   \n";
    cout <<"3- Gestion des commandes \n";
    cout <<"4- Gestion des livraisons \n";
    cout <<"5- Calculer le capital du supermarche \n\n";
    cout <<"_________________________________________________________________ \n\n";
    cout <<"    Votre choix : " <<endl; cin >> n;

    if(n == 1)
        choix_article();
    else if(n==2)
        choix_client();
    else if (n==3)
        choix_commande();
    else if (n==4)
        choix_livraison();
    //else if (n==5)
     //   choix_capital();
    else
    {
       cout << " \n\nChoix indisponible.....\n\n";
       system("PAUSE");
       menu4();
    }


}
#endif
